#include <windows.h>
#include "gsmmodem.h"
 
int wmain(void)
{
    HANDLE gsmHandle = NULL;                 ///< Handle for COM port 
    BOOL returnValue = 0;                    ///< variable holding return values
    char phoneNumber[16] = {0};
    char messageRecieved[160] = {0};
    char dateTimeStamp[21] = {0};
    char IMEINumber[IMEI_NUMBER_MAX_LENGTH + 1] = {0};
    char manufacturerName[100] = {0};
    char modelNumber[100] = {0};
    char networkProvider[50] = {0};
    char signalStrength[4] = {0};
    char date[DATE_MAX_LENGTH + 1] = {0};
    char time[TIME_MAX_LENGTH + 1] = {0};
    DWORD SimStatus = 0;
    DWORD networkStatus = 0;
 
    /// Configure COM port for GSM modem
    returnValue = GsmOpen(&gsmHandle, 9600);
    if (returnValue == FALSE)
    {
        printf("cannot open port \n");
        getchar();
        return FALSE;
    }
    returnValue = SendATCommand(gsmHandle, "AT", TRUE, "OK");    ///< Check communication with modem
    if (returnValue == FALSE)
    {
        printf("error \n");
        getchar();
        return FALSE;
    }
    returnValue = SendATCommand(gsmHandle, "ATE0", TRUE, "OK");  ///< Disable echo
    if (returnValue == FALSE)
    {
        printf("cannot disable echo \n");
        getchar();
        return FALSE;
    }
 
    returnValue = GsmGetIMEINumber(gsmHandle, IMEINumber);
    if (returnValue == FALSE)
    {
        printf("error in obtaining IMEI number \n");
        getchar();
        return FALSE;
    }
    printf(" IMEI = %s\n", IMEINumber);
    returnValue = GsmGetManufacturerInfo(gsmHandle, manufacturerName, modelNumber);
    if (returnValue == FALSE)
    {
        printf("error in obtaining manufacturer information \n");
        getchar();
        return FALSE;
    }
    printf(" Manufacturer Name = %s, Model Number = %s\n", manufacturerName, modelNumber);
    returnValue = GsmGetSIMStaus(gsmHandle, &SimStatus); 
    if (returnValue == FALSE)
    {
        printf("error to obtain SIM status\n");
        getchar();
        return FALSE;
    }
    returnValue = GsmGetSignalStength(gsmHandle, signalStrength);
    if (returnValue == FALSE)
    {
        getchar();
        return FALSE;
    }
    printf(" Signal Strength = %s \n", signalStrength);
    returnValue = GsmGetNetworkRegistrationSIMStaus(gsmHandle, &networkStatus, networkProvider); 
    if (returnValue == FALSE)
    {
        getchar();
        return FALSE;
    }
    printf(" Network Status = %d, Network Provider = %s \n", networkStatus, networkProvider);
 
    returnValue = GsmGetNetworkDateTimeInformation(gsmHandle, date, time);
    if (returnValue == FALSE)
    {
        getchar();
        return FALSE;
    }
    printf(" date = %s, time = %s\n", date, time);
    returnValue = SendATCommand(gsmHandle, "AT+CMGF=1", TRUE, "OK");  ///< Set Text Mode
    if (returnValue == FALSE)
    {
        printf("cannot set to text mode \n");
        getchar();
        return FALSE;
    }
    /// Example to send SMS
    returnValue = GsmSendSms(gsmHandle, "+918792792826", "Toradex GSM Modem Test  ", 0);
    Sleep(2000);
 
    /// Example to receive SMS
    //returnValue = GsmRecieveSms(gsmHandle, "1", phoneNumber, dateTimeStamp, messageRecieved, 160); 
 
    /// Example to delete SMS
    //returnValue = GsmDeleteSms(gsmHandle, "1");

    /// Example to give a miss call
    //returnValue = GsmGiveMissCall(gsmHandle, "+917204200289", 0);
    printf(" press enter to exit\n");
    getchar();
    GsmClose(&gsmHandle);         ///< Free resources allocated 
    return TRUE;
}