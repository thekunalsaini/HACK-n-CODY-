/// @file       gsmmodem.h
/// @copyright  Copyright (c) 2014 Toradex AG
/// @date       $ 2014-03-26 $
/// @brief      Contains function declarations to be used to access GSM Modem

#ifndef _GSMMODEM_H_
#define _GSMMODEM_H_
 
#include <windows.h>
 
#define DELIVERY_REPORT_SMS_SENT        0
#define DELIVERY_REPORT_SMS_DELIVERED   1
#define IMEI_NUMBER_MAX_LENGTH          15
#define DATE_MAX_LENGTH                 8
#define TIME_MAX_LENGTH                 11
 
 //******************************************************************************
/// Configure COM port to communicate with GSM modem
/// @param[out]    port           COM port for GSM modem 
/// @param[in]     baudRate       Baudrate for communication
/// @retval        TRUE           Success
///                FALSE          Failure
BOOL GsmOpen(HANDLE *port, DWORD baudRate);
 
//******************************************************************************
/// Send SMS to a phone number
/// @param[in]     port              GSM Port Handle returned by call to GsmOpen().
/// @param[in]     phoneNumber       Phone number to which SMS is send
/// @param[in]     message           Message to send in SMS
/// @param[out]    deliveryReport    Message delivery report
/// @retval        TRUE              Success
///                FALSE             See GetLastError()
BOOL GsmSendSms(HANDLE port, char *phoneNumber, char *message, DWORD *deliveryReport);
 
//******************************************************************************
/// Read received SMS
/// @param[in]     port                 GSM Port Handle returned by call to GsmOpen().
/// @param[in]     messageIndex         Index of received SMS
/// @param[out]    senderPhoneNumber    SMS sender phone number
/// @param[out]    dateTimeStamp        Date and time of received SMS
/// @param[out]    message              Message received in SMS
/// @param[in]     messageSize          Message size
/// @retval        TRUE                 Success
///                FALSE                Failure
BOOL GsmRecieveSms(HANDLE port, char *messageIndex, char *senderPhoneNumber, char *dateTimeStamp, char *message, DWORD messageSize);
 
//******************************************************************************
/// Delete SMS 
/// @param[in]     port           GSM Port Handle returned by call to GsmOpen().
/// @param[in]     messageIndex   Index of SMS to be deleted
/// @retval        TRUE           Success
///                FALSE          Failure
BOOL GsmDeleteSms(HANDLE port, char *messageIndex);
 
//******************************************************************************
/// Give miss call on a phone number
/// @param[in]     port              GSM Port Handle returned by call to GsmOpen().
/// @param[in]     phoneNumber       Phone number
/// @param[out]    deliveryReport    delivery report
/// @retval        TRUE              Success
///                FALSE             Failure
BOOL GsmGiveMissCall(HANDLE port, char *phoneNumber, DWORD *deliveryReport);
 
//******************************************************************************
/// Close COM port used for GSM modem
/// @param[in]     port           GSM Port Handle returned by call to GsmOpen().
/// @retval        TRUE           Success
///                FALSE          Failure
BOOL GsmClose(HANDLE *port);
 
//******************************************************************************
/// Send AT command to GSM modem
/// @param[in]    port             GSM Port Handle returned by call to GsmOpen().
/// @param[in]    commandString    AT command to be send
/// @param[in]    terminate        End of message
/// @param[in]    responseString   Expected AT command response
/// @retval       TRUE             Success
///               FALSE            Failure
BOOL SendATCommand(HANDLE port, char *commandString, BOOL terminate, char *responseString);
 
//******************************************************************************
/// Gets IMEI number of the modem
/// @param[in]    port           GSM Port Handle returned by call to GsmOpen().
/// @param[out]   imeiNumber     IMEI number of the device
/// @retval       TRUE           Success
///               FALSE          Failure
BOOL GsmGetIMEINumber(HANDLE port, char *imeiNumber);
 
//******************************************************************************
/// Gets information about modem manufacturer
/// @param[in]    port           GSM Port Handle returned by call to GsmOpen().
/// @param[out]   manufacturer   Manufacturer information
/// @param[out]   modelNumber    Model number of modem
/// @retval       TRUE           Success
///               FALSE          Failure
BOOL GsmGetManufacturerInfo(HANDLE port, char *manufacturer, char *modelNumber);
 
//******************************************************************************
/// Gets SIM pin status
/// @param[in]    port           GSM Port Handle returned by call to GsmOpen().
/// @param[out]   status         SIM status
/// @retval                      Returns the status of SIM
BOOL GsmGetSIMStaus(HANDLE port, DWORD *status);
 
//******************************************************************************
/// Gets information of SIM registration and network provider 
/// @param[in]    port                GSM Port Handle returned by call to GsmOpen().
/// @param[out]   status              Status of SIM registration 
/// @param[out]   networkProvider     Network provider information
/// @retval       TRUE                Success
/// @retval       FALSE               Failure
BOOL GsmGetNetworkRegistrationSIMStaus(HANDLE port, DWORD *status, char *networkProvider);
 
//******************************************************************************
/// Gets signal strength information
/// @param[in]    port              GSM Port Handle returned by call to GsmOpen().
/// @param[out]   signalStrength    signal strength information
/// @retval       TRUE              Success
///               FALSE             Failure
BOOL GsmGetSignalStength(HANDLE port, char *signalStrength);
 
//******************************************************************************
/// Gets Network Date and Time Information
/// @param[in]   port           GSM Port Handle returned by call to GsmOpen().
/// @param[out]  date           Pointer to date string
/// @param[out]  time           Pointer to time string
/// @retval      TRUE           Success
///              FALSE          Failure
BOOL GsmGetNetworkDateTimeInformation(HANDLE port, char *date, char *time);

#endif // _GSMMODEM_H_